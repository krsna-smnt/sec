#include<bits/stdc++.h>
#include<gmp.h>
using namespace std;
int main()
{
    mpz_t xa,xb,ya,yb,g,p,d,c1,c2,K,k,a,b,c,msg,maxi;
    mpz_inits(xa,xb,ya,yb,g,d,p,c1,c2,K,k,a,b,c,msg,maxi,NULL);
    gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed  = time(NULL);
	gmp_randseed_ui(state,seed);
	
    gmp_printf("give p,g");
    gmp_scanf("%Zd",p);
    gmp_scanf("%Zd",g);
    mpz_sub_ui(d,p,3);
	mpz_urandomm(xa,state,d);
	mpz_add_ui(xa,xa,1);
    mpz_powm(ya,g,xa,p);
    
    	mpz_urandomm(xb,state,d);
	mpz_add_ui(xb,xb,1);
    mpz_powm(yb,g,xb,p);
    
    
     mpz_sub_ui(d,p,2);
	mpz_urandomm(k,state,d);
		mpz_add_ui(k,k,1);
		mpz_powm(K,yb,k,p);
		unsigned long max=123456;
		mpz_set_ui(maxi,max);
		mpz_urandomm(msg,state,maxi);
		//mpz_set_ui(msg,12345);
		mpz_mul(c2,msg,K);
		mpz_powm(c1,g,k,p);
		
    mpz_powm(c,c1,xb,p);
    mpz_fdiv_q(a,c2,c);
     gmp_printf("%Zd is the msg \n ",a);
      gmp_printf("%Zd is c1 \n %Zd is c2 \n   ",c1,c2);
    gmp_printf(" \n %Zd is the decryped msg",a);
		
		
		
		
		
    
	return 0;
}
