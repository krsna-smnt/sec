#include<bits/stdc++.h>
#include<gmp.h>
#include<time.h>
using namespace std;
int main()
{
    mpz_t xa,xb,ya,yb,g,p,d,c1,c2,K,k,a,b,c,msg,v1,v2,di;
    mpz_inits(xa,xb,ya,yb,g,d,p,c1,c2,K,k,a,b,c,msg,v1,v2,di,NULL);
    gmp_randstate_t state;
	gmp_randinit_mt(state);
	unsigned long seed;
	seed  = time(NULL);
	gmp_randseed_ui(state,seed);
	
    gmp_printf("give p,g");
    gmp_scanf("%Zd",p);
    gmp_scanf("%Zd",g);
    mpz_sub_ui(d,p,3);
	mpz_urandomm(xa,state,d);
	mpz_add_ui(xa,xa,1);
    mpz_powm(ya,g,xa,p);
    
    	mpz_urandomm(xb,state,d);
	mpz_add_ui(xb,xb,1);
    mpz_powm(yb,g,xb,p);
    
       gmp_printf("%Zd is xa and %Zd is ya \n  ",xa,ya );
            gmp_printf("%Zd is xb and %Zd is yb \n  ",xb,yb );
     mpz_sub_ui(d,p,2);
	mpz_urandomm(k,state,d);
		mpz_add_ui(k,k,1);
		//find k ^(-1) mod p-1 and 1<=k<q-1
		mpz_sub_ui(d,p,1);
		mpz_invert(c,k,d);
	    mpz_powm(c1,g,k,p);
	        mpz_set_ui(di,123456);
		mpz_urandomm(msg,state,di);//msg
	    	mpz_mul(b,xa,c1);
	    	mpz_sub(K,msg,b);
	    	mpz_mul(c2,c,K);
	    	mpz_sub_ui(d,p,1);
	    	mpz_mod(c2,c2,d);
		
    
     gmp_printf("%Zd is the msg %Zd k ,%Zd k^-1 \n",msg,k,c);
      gmp_printf("%Zd is c1 and %Zd is c2  ",c1,c2);
      
      //verification v1=g^m mod p
      //v2=(ya^c1)*(c1^c2)mod p
      //show v1=v2
	 mpz_powm(v1,g,msg,p);
	 mpz_powm(a,c1,c2,p);
	 mpz_powm(b,ya,c1,p);
	 mpz_mul(b,a,b);
	 mpz_mod(v2,b,p);
	 if(mpz_cmp(v1,v2)==0)
	 {
	 	printf("verified succesfully");
	 }
	 else
	 {
	 		printf("verified unsuccessful");
	 }
		

	return 0;
}
