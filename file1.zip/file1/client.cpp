#include <netdb.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void func(int sfd)
{
	char buff[100];
	while(1)
	{
		printf("Enter message: ");
		fgets(buff,100,stdin);
	
		send(sfd,buff,sizeof(buff),0);
		
		recv(sfd,buff,sizeof(buff),0);
		printf("Message received from server: %s\n",buff);
	}
}

int main()
{
	struct sockaddr_in server;
	
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	printf("Socket creation failed\n");
	else
	printf("Socket successfully created\n");
	
	bzero(&server, sizeof(server)); 
  
    server.sin_family = AF_INET; 
    server.sin_addr.s_addr = inet_addr("127.0.0.1"); 
    server.sin_port = htons(8080);
    
    int connectcheck = connect(sfd,(struct sockaddr*)&server,sizeof(server));
    if(connectcheck!=0)
    printf("Connection failed\n");
    else
    printf("Server connection successful\n");
   
	func(sfd);

	return 0;
}

