#include <bits/stdc++.h> 

using namespace std; 

int inv(int a, int n) { 
	int n_0 = n, t, q; 
	int x_0 = 0, x_1 = 1; 
  
	if (n == 1) 
	   return 0; 
  
	while (a > 1) { 
		q = a / n;   
		t = n; 

		n = a % n, a = t;   
		t = x_0; 
		x_0 = x_1 - q * x_0; 
		x_1 = t; 
	} 
  
	if (x_1 < 0) 
	   x_1 += n_0; 
  
	return x_1; 
} 
  
int res_(vector<int>& num, vector<int>& rem) { 
	int prd = 1; 
	for (int i = 0; i < num.size(); i++) 
		prd *= num[i]; 
  
	int res = 0;   
	for (int i = 0; i < num.size(); i++) { 
		int p1 = prd / num[i]; 
		res += rem[i] * inv(p1, num[i]) * p1; 
	} 
  
	return res % prd; 
} 
  
int main() { 
	int n;
	cout<<"\nenter size\n";
	cin>>n;
	vector<int> num(n); 
	vector<int> rem(n); 
	cout<<"\enter nums\n";
	for(int i = 0; i < n; i++)
		cin>>num[i];

	cout<<"\nenter mods\n";
	for(int i = 0; i < n; i++)
		cin>>rem[i];

	cout << "\nAns=>\n";
	cout << res_(num, rem); 
	return 0; 
} 
