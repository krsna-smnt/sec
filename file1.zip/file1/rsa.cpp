#include<bits/stdc++.h>

using namespace std;

int gcd(int a, int h) { 
    int temp; 
    while (true) { 
        temp = a%h; 
        if (temp == 0) 
          return h; 
        a = h; 
        h = temp; 
    } 
} 
  
int main() { 
    int p, q;

    cout << "\np,q\n";
    cin >> p >> q; 
  
    int n = p*q;
  
    int e = 2; 
    int phi = (p-1)*(q-1); 
    while (e < phi) { 
        if (gcd(e, phi)==1) 
            break; 
        else
           ++e; 
    } 
  
    int k = 2;
    int d = (1 + (k*phi))/e; 
    int ms;   
    cout<<"\nm\n";
    cin>>ms;
    int c = pow(ms, e); 
    c = fmod(c, n); 
    printf("\nct = %lf", double(c)); 
    int m = pow(c, d); 
    m = fmod(double(m), n); 
    printf("\nm = %lf\n", double(m));   

    return 0; 
} 
