#include <netdb.h> 
#include <netinet/in.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <stdio.h>


void func(int nsfd)
{
	while(1)
	{
		char buff[100];
		recv(nsfd,buff,sizeof(buff),0);
		
		printf("Message received from client: %s\n",buff);
		
		printf("Enter message: ");
		fgets(buff,100,stdin);
		
		send(nsfd,buff,sizeof(buff),0);
	}
}

int main()
{

	struct sockaddr_in server,client;
	int sfd = socket(AF_INET,SOCK_STREAM,0);
	if(sfd==-1)
	printf("Socket creation failed\n");
	else
	printf("Socket successfully created\n");
	
	bzero(&server,sizeof(server));
	
	server.sin_family = AF_INET; 
    server.sin_addr.s_addr = htonl(INADDR_ANY); 
    server.sin_port = htons(8080);
    
    int bindcheck = bind(sfd,(struct sockaddr*)&server,sizeof(server));
    if(bindcheck!=0)
    printf("Bind Failed\n");
    else
    printf("Successfully Binded\n"); 
    
    int listencheck = listen(sfd,5);
    if(listencheck!=0)
    printf("Listen failed\n");
    else
    printf("Server listening\n");
    
    int len = (int)sizeof(client);
    int nsfd = accept(sfd,(struct sockaddr*)&client,(socklen_t*)&len);
    if(nsfd<0)
    printf("Server accept failed\n");
    else
    printf("Client accepted by the server\n");

	//int check = getpeername(nsfd,(struct sockaddr*)&client,&len);
	//printf("%d\n",check);
    
    func(nsfd);
    
    
}

